import React from 'react';

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  image: string;
  colSpan: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export enum Section {
  HERO = 'hero',
  SERVICES = 'services',
  TECH = 'tech',
  GALLERY = 'gallery',
  CONTACT = 'contact'
}