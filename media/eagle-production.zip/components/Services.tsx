import React from 'react';
import { HardDrive, Film, Clapperboard, Check, Plus, Car, Camera, Usb, ArrowRight } from 'lucide-react';

export const Services: React.FC = () => {
  return (
    <div className="bg-background py-32 relative overflow-hidden">
      {/* Background Ambient Glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-accent/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        
        {/* Header */}
        <div className="text-center mb-20">
          <h2 className="text-5xl md:text-7xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-textPrimary to-textPrimary/60 mb-6">
            Nos Formules.
          </h2>
          <p className="text-xl text-textSecondary max-w-2xl mx-auto font-light leading-relaxed">
            Des solutions adaptées à chaque besoin. Du rush brut à la production cinématographique complète.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start mb-24">
          
          {/* Card 1: ESSENTIEL (Silver/Monochrome) */}
          <div className="group relative bg-surfaceHighlight/30 backdrop-blur-xl border border-white/5 rounded-3xl p-8 hover:bg-surfaceHighlight/50 transition-all duration-500 hover:-translate-y-2">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-white/20 to-transparent opacity-50 rounded-t-3xl"></div>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 rounded-2xl bg-white/5 text-textPrimary">
                <HardDrive size={24} />
              </div>
              <h3 className="text-2xl font-bold text-textPrimary">Essentiel</h3>
            </div>
            <p className="text-textSecondary text-sm mb-8 h-10">
              Sans montage. Exploitez vos images comme vous le souhaitez. Livraison des fichiers bruts.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-end border-b border-white/5 pb-4">
                <span className="text-textPrimary font-medium">1h de prise de vue</span>
                <span className="text-3xl font-bold text-textPrimary">50€</span>
              </div>
              <div className="flex justify-between items-end border-b border-white/5 pb-4">
                <span className="text-textPrimary font-medium">2h de prise de vue</span>
                <span className="text-3xl font-bold text-textPrimary">100€</span>
              </div>
            </div>

            <ul className="space-y-3">
              <li className="flex gap-3 text-sm text-textSecondary">
                <Check size={16} className="text-textPrimary mt-0.5" />
                <span>Vidéos brutes non retouchées</span>
              </li>
              <li className="flex gap-3 text-sm text-textSecondary">
                <Check size={16} className="text-textPrimary mt-0.5" />
                <span>Liberté totale de post-production</span>
              </li>
            </ul>
          </div>

          {/* Card 2: ALTITUDE (Gold/Accent) */}
          <div className="group relative bg-surfaceHighlight border border-accent/30 rounded-3xl p-8 lg:scale-105 shadow-2xl shadow-accent/5 z-10 transition-all duration-500 hover:border-accent/50">
             <div className="absolute top-0 right-0 bg-accent text-background text-xs font-bold px-3 py-1 rounded-bl-xl rounded-tr-2xl">POPULAIRE</div>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 rounded-2xl bg-accent/20 text-accent">
                <Film size={24} />
              </div>
              <h3 className="text-2xl font-bold text-textPrimary">Altitude</h3>
            </div>
            <p className="text-textSecondary text-sm mb-8 h-10">
              Avec montage vidéo. Offrez-vous une vidéo personnalisée et immersive clé en main.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-end border-b border-white/5 pb-4">
                <div>
                    <span className="text-textPrimary font-medium block">Classique</span>
                    <span className="text-xs text-textSecondary">0 à 3 minutes</span>
                </div>
                <span className="text-4xl font-bold text-accent">150€</span>
              </div>
              <div className="flex justify-between items-end border-b border-white/5 pb-4">
                <div>
                    <span className="text-textPrimary font-medium block">Altitude +</span>
                    <span className="text-xs text-textSecondary">3 à 5 minutes</span>
                </div>
                <span className="text-4xl font-bold text-accent">250€</span>
              </div>
            </div>

            <ul className="space-y-3">
              <li className="flex gap-3 text-sm text-gray-300">
                <Check size={16} className="text-accent mt-0.5" />
                <span>Montage dynamique inclus</span>
              </li>
              <li className="flex gap-3 text-sm text-gray-300">
                <Check size={16} className="text-accent mt-0.5" />
                <span>Musique libre de droits</span>
              </li>
              <li className="flex gap-3 text-sm text-gray-300">
                <Check size={16} className="text-accent mt-0.5" />
                <span>Étalonnage couleur basique</span>
              </li>
            </ul>
            
            <button className="w-full mt-8 bg-textPrimary text-background font-semibold py-3 rounded-xl hover:bg-white transition-colors">
              Choisir Altitude
            </button>
          </div>

          {/* Card 3: HORIZON (Premium Gold) */}
          <div className="group relative bg-surfaceHighlight/30 backdrop-blur-xl border border-white/5 rounded-3xl p-8 hover:bg-surfaceHighlight/50 transition-all duration-500 hover:-translate-y-2">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-accent/50 to-accent/10 opacity-50 rounded-t-3xl"></div>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 rounded-2xl bg-accent/10 text-accent">
                <Clapperboard size={24} />
              </div>
              <h3 className="text-2xl font-bold text-textPrimary">Horizon</h3>
            </div>
            <p className="text-textSecondary text-sm mb-8 h-10">
              Réalisation complète. Une production inspirée de vos idées pour un résultat cinéma.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-end border-b border-white/5 pb-4">
                <div>
                    <span className="text-textPrimary font-medium block">Classique</span>
                    <span className="text-xs text-textSecondary">5 à 10 minutes</span>
                </div>
                <span className="text-3xl font-bold text-textPrimary">500€</span>
              </div>
              <div className="flex justify-between items-end border-b border-white/5 pb-4">
                <div>
                    <span className="text-textPrimary font-medium block">Horizon +</span>
                    <span className="text-xs text-textSecondary">10 à 20 minutes</span>
                </div>
                <span className="text-3xl font-bold text-textPrimary">1000€</span>
              </div>
            </div>

            <ul className="space-y-3">
              <li className="flex gap-3 text-sm text-textSecondary">
                <Check size={16} className="text-accent mt-0.5" />
                <span>Scénarisation complète</span>
              </li>
              <li className="flex gap-3 text-sm text-textSecondary">
                <Check size={16} className="text-accent mt-0.5" />
                <span>Post-production avancée (VFX)</span>
              </li>
              <li className="flex gap-3 text-sm text-textSecondary">
                <Check size={16} className="text-accent mt-0.5" />
                <span>Sound Design immersif</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Extras & Info Section */}
        <div className="bg-white/5 rounded-3xl border border-white/5 p-8 md:p-12">
            <div className="flex flex-col md:flex-row items-center justify-between gap-12">
                
                {/* Text Info */}
                <div className="flex-1 text-center md:text-left">
                    <h4 className="text-2xl font-bold text-textPrimary mb-4">Infos Supplémentaires</h4>
                    <p className="text-textSecondary mb-6">
                        Une demande particulière ? Des besoins spécifiques pour l'industrie ou l'immobilier ?
                    </p>
                    <button className="flex items-center gap-2 text-accent hover:text-textPrimary transition-colors mx-auto md:mx-0">
                        Contactez-nous pour un devis <ArrowRight size={16} />
                    </button>
                </div>

                {/* Grid of Extras */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 w-full md:w-auto">
                    <div className="bg-surfaceHighlight p-6 rounded-2xl border border-white/5 text-center group hover:border-accent/30 transition-colors">
                        <Car className="w-8 h-8 text-textPrimary mx-auto mb-3 opacity-50 group-hover:opacity-100 transition-opacity" />
                        <div className="text-2xl font-bold text-textPrimary mb-1">0,50€</div>
                        <div className="text-xs text-textSecondary uppercase tracking-wider">Par Kilomètre</div>
                    </div>
                    <div className="bg-surfaceHighlight p-6 rounded-2xl border border-white/5 text-center group hover:border-accent/30 transition-colors">
                        <Camera className="w-8 h-8 text-textPrimary mx-auto mb-3 opacity-50 group-hover:opacity-100 transition-opacity" />
                        <div className="text-2xl font-bold text-textPrimary mb-1">2€</div>
                        <div className="text-xs text-textSecondary uppercase tracking-wider">Par Photo</div>
                    </div>
                    <div className="bg-surfaceHighlight p-6 rounded-2xl border border-white/5 text-center group hover:border-accent/30 transition-colors">
                        <Usb className="w-8 h-8 text-textPrimary mx-auto mb-3 opacity-50 group-hover:opacity-100 transition-opacity" />
                        <div className="text-2xl font-bold text-textPrimary mb-1">12€</div>
                        <div className="text-xs text-textSecondary uppercase tracking-wider">Clé USB</div>
                    </div>
                </div>

            </div>
        </div>

      </div>
    </div>
  );
};