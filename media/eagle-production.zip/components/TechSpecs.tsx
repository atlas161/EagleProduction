import React from 'react';

export const TechSpecs: React.FC = () => {
  return (
    <div className="bg-surface py-32 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center gap-12">
        <div className="flex-1 space-y-8">
          <h2 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-accent to-textPrimary">
            Performance Pure.
          </h2>
          <p className="text-2xl text-textPrimary leading-relaxed font-light">
            Nos machines ne sont pas de simples drones. Ce sont des plateformes volantes de haute précision.
          </p>
          
          <div className="grid grid-cols-2 gap-8 pt-8">
            <div className="border-l border-white/20 pl-6">
              <div className="text-3xl font-semibold text-textPrimary">5.4K</div>
              <div className="text-textSecondary text-sm mt-1 uppercase tracking-wider">Résolution Vidéo</div>
            </div>
            <div className="border-l border-white/20 pl-6">
              <div className="text-3xl font-semibold text-textPrimary">45min</div>
              <div className="text-textSecondary text-sm mt-1 uppercase tracking-wider">Autonomie de Vol</div>
            </div>
            <div className="border-l border-white/20 pl-6">
              <div className="text-3xl font-semibold text-textPrimary">70km/h</div>
              <div className="text-textSecondary text-sm mt-1 uppercase tracking-wider">Vitesse de Pointe</div>
            </div>
            <div className="border-l border-white/20 pl-6">
              <div className="text-3xl font-semibold text-textPrimary">IP55</div>
              <div className="text-textSecondary text-sm mt-1 uppercase tracking-wider">Résistance Météo</div>
            </div>
          </div>
        </div>

        <div className="flex-1 relative h-[500px] w-full rounded-3xl overflow-hidden bg-gradient-to-br from-surfaceHighlight to-background flex items-center justify-center border border-white/10 shadow-2xl">
          {/* Abstract representation of a drone or sensor */}
           <img 
            src="https://picsum.photos/600/600?grayscale" 
            alt="Drone Sensor" 
            className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-overlay"
          />
          <div className="relative z-10 text-center">
            <div className="w-32 h-32 rounded-full border border-accent/30 flex items-center justify-center animate-pulse mx-auto mb-4 bg-accent/5 backdrop-blur-xl">
               <div className="w-24 h-24 rounded-full bg-accent/20 blur-xl"></div>
            </div>
            <p className="font-mono text-accent text-sm">SENSORS_ACTIVE</p>
          </div>
        </div>
      </div>
    </div>
  );
};