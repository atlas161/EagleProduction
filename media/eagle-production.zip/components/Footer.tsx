import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-surfaceHighlight border-t border-white/5 py-12">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-textSecondary text-sm">
          &copy; {new Date().getFullYear()} Eagle Production. Tous droits réservés.
        </div>
        <div className="flex gap-6 text-sm text-textSecondary">
          <a href="#" className="hover:text-accent transition-colors">Mentions Légales</a>
          <a href="#" className="hover:text-accent transition-colors">Confidentialité</a>
          <a href="#" className="hover:text-accent transition-colors">Instagram</a>
          <a href="#" className="hover:text-accent transition-colors">LinkedIn</a>
        </div>
      </div>
    </footer>
  );
};