import React, { useState, useEffect } from 'react';
import { Section } from '../types';
import { Menu, X } from 'lucide-react';

interface NavbarProps {
  activeSection: Section;
  scrollToSection: (section: Section) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeSection, scrollToSection }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: Section.SERVICES, label: 'Services' },
    { id: Section.TECH, label: 'Technologie' },
    { id: Section.GALLERY, label: 'Galerie' },
    { id: Section.CONTACT, label: 'Contact' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || isMobileMenuOpen ? 'bg-background/80 backdrop-blur-xl border-b border-white/10' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo & Brand Name */}
        <div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => scrollToSection(Section.HERO)}
        >
          {/* Logo Eagle Production (Custom SVG Reproduction) */}
          <div className="text-accent group-hover:scale-105 transition-transform duration-300 h-10 w-auto flex items-center">
             <svg viewBox="0 0 240 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-full w-auto">
                <defs>
                  <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#D4AF37" stopOpacity="0.4" />
                    <stop offset="50%" stopColor="#D4AF37" stopOpacity="1" />
                    <stop offset="100%" stopColor="#D4AF37" stopOpacity="0.4" />
                  </linearGradient>
                </defs>
                
                {/* Left Rotor Halo */}
                <ellipse cx="50" cy="30" rx="40" ry="8" stroke="url(#goldGrad)" strokeWidth="3" />
                
                {/* Right Rotor Halo */}
                <ellipse cx="190" cy="30" rx="40" ry="8" stroke="url(#goldGrad)" strokeWidth="3" />
                
                {/* Eagle Body Silhouette */}
                <path 
                  d="M120 110 C110 100 90 80 70 70 C60 65 50 70 40 75 C50 60 70 50 90 60 L110 75 L120 80 L130 75 L150 60 C170 50 190 60 200 75 C190 70 180 65 170 70 C150 80 130 100 120 110 Z" 
                  fill="#FFFCF2" 
                  opacity="0.9"
                />
                {/* Eagle Head details */}
                <path d="M130 75 L135 72 L132 78 Z" fill="#FFFCF2" />
             </svg>
          </div>
          <span className="text-lg font-bold tracking-wide text-textPrimary">Eagle Production</span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => scrollToSection(link.id)}
              className={`text-xs font-medium tracking-wider transition-colors duration-200 ${
                activeSection === link.id ? 'text-accent' : 'text-textSecondary hover:text-white'
              }`}
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => scrollToSection(Section.CONTACT)}
            className="bg-accent text-background text-xs font-bold px-4 py-2 rounded-full hover:bg-white transition-colors"
          >
            Devis Gratuit
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-textPrimary"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 w-full bg-surface border-b border-white/10 px-6 py-8 flex flex-col gap-6 animate-fade-in">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => {
                scrollToSection(link.id);
                setIsMobileMenuOpen(false);
              }}
              className="text-lg font-medium text-left text-textPrimary hover:text-accent"
            >
              {link.label}
            </button>
          ))}
        </div>
      )}
    </nav>
  );
};