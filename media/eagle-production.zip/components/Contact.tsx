import React from 'react';

export const Contact: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto px-6 py-24">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold mb-4">Parlons de votre projet.</h2>
        <p className="text-textSecondary">
          Remplissez le formulaire ou utilisez notre assistant IA pour une estimation rapide.
        </p>
      </div>

      <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-textSecondary uppercase tracking-wider ml-2">Nom</label>
            <input
              type="text"
              className="w-full bg-surfaceHighlight border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-accent transition-colors"
              placeholder="Votre Nom"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-semibold text-textSecondary uppercase tracking-wider ml-2">Email</label>
            <input
              type="email"
              className="w-full bg-surfaceHighlight border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-accent transition-colors"
              placeholder="votre@email.com"
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <label className="text-xs font-semibold text-textSecondary uppercase tracking-wider ml-2">Message</label>
          <textarea
            rows={4}
            className="w-full bg-surfaceHighlight border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-accent transition-colors resize-none"
            placeholder="Détails de votre mission..."
          ></textarea>
        </div>

        <button className="w-full bg-white text-black font-semibold py-4 rounded-xl hover:bg-neutral-200 transition-colors">
          Envoyer la demande
        </button>
      </form>
    </div>
  );
};