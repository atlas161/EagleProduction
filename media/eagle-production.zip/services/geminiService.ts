import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateChatResponse = async (history: { role: string; text: string }[], newMessage: string): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    
    const systemPrompt = `Tu es "EagleBot", l'assistant virtuel expert d'Eagle Production, une société de services de drones haut de gamme.
    Tes réponses doivent être concises, élégantes, professionnelles et serviables.
    
    VOICI LES TARIFS ET FORMULES OFFICIELS (À utiliser pour répondre aux questions de prix) :
    
    1. FORMULE ESSENTIEL (Sans montage, livraison des rushs bruts) :
       - 1h de prise de vue : 50€
       - 2h de prise de vue : 100€
       
    2. FORMULE ALTITUDE (Avec montage vidéo, personnalisé et immersif) :
       - Altitude Classique (Vidéo 0 à 3 min) : 150€
       - Altitude + (Vidéo 3 à 5 min) : 250€
       
    3. FORMULE HORIZON (Avec montage, réalisation complète scénarisée) :
       - Horizon Classique (Vidéo 5 à 10 min) : 500€
       - Horizon + (Vidéo 10 à 20 min) : 1000€
       
    4. FRAIS ET OPTIONS SUPPLÉMENTAIRES :
       - Frais kilométriques : 0.50€ / km
       - Prise de photo au drone : 2€ / image
       - Livraison sur clé USB : 12€
    
    Si on te demande un devis personnalisé pour une demande particulière, encourage l'utilisateur à utiliser le formulaire de contact.
    Reste courtois et bref.`;

    const chatContext = history.map(msg => `${msg.role}: ${msg.text}`).join('\n');
    const fullPrompt = `${systemPrompt}\n\nHistorique:\n${chatContext}\n\nUser: ${newMessage}\nModel:`;

    const response = await ai.models.generateContent({
      model: model,
      contents: fullPrompt,
    });

    return response.text || "Désolé, je n'ai pas pu traiter votre demande pour le moment.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Une erreur est survenue. Veuillez réessayer plus tard.";
  }
};