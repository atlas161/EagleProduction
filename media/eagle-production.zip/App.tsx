import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { TechSpecs } from './components/TechSpecs';
import { Contact } from './components/Contact';
import { AIChat } from './components/AIChat';
import { Footer } from './components/Footer';
import { Section } from './types';

function App() {
  const [activeSection, setActiveSection] = useState<Section>(Section.HERO);

  const scrollToSection = (sectionId: Section) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(sectionId);
    }
  };

  return (
    <div className="min-h-screen bg-background text-textPrimary font-sans selection:bg-accent selection:text-white">
      <Navbar activeSection={activeSection} scrollToSection={scrollToSection} />
      
      <main>
        <section id={Section.HERO}>
          <Hero onScrollDown={() => scrollToSection(Section.SERVICES)} />
        </section>

        <section id={Section.SERVICES} className="relative z-10 bg-background">
          <Services />
        </section>

        <section id={Section.TECH}>
          <TechSpecs />
        </section>

        <section id={Section.GALLERY} className="py-24 px-6 max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">Galerie</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 h-[600px]">
             <div className="col-span-2 row-span-2 rounded-2xl overflow-hidden group relative">
                <img src="https://picsum.photos/800/800?random=10" className="w-full h-full object-cover transition duration-700 group-hover:scale-110" alt="Gallery 1" />
             </div>
             <div className="col-span-1 row-span-1 rounded-2xl overflow-hidden group relative">
                <img src="https://picsum.photos/400/400?random=11" className="w-full h-full object-cover transition duration-700 group-hover:scale-110" alt="Gallery 2" />
             </div>
             <div className="col-span-1 row-span-2 rounded-2xl overflow-hidden group relative">
                <img src="https://picsum.photos/400/800?random=12" className="w-full h-full object-cover transition duration-700 group-hover:scale-110" alt="Gallery 3" />
             </div>
             <div className="col-span-1 row-span-1 rounded-2xl overflow-hidden group relative">
                <img src="https://picsum.photos/400/400?random=13" className="w-full h-full object-cover transition duration-700 group-hover:scale-110" alt="Gallery 4" />
             </div>
          </div>
        </section>

        <section id={Section.CONTACT} className="bg-gradient-to-b from-background to-surfaceHighlight">
          <Contact />
        </section>
      </main>

      <Footer />
      <AIChat />
    </div>
  );
}

export default App;